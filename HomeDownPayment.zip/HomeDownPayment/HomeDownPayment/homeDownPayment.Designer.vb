﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class homeDownPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(homeDownPayment))
        Me.lblDownPayment = New System.Windows.Forms.Label()
        Me.lblInterestRate = New System.Windows.Forms.Label()
        Me.lblNumberOfYears = New System.Windows.Forms.Label()
        Me.txtDownPayment = New System.Windows.Forms.TextBox()
        Me.txtInterestRate = New System.Windows.Forms.TextBox()
        Me.txtNumberOfYears = New System.Windows.Forms.TextBox()
        Me.lblPayment = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDownPayment
        '
        Me.lblDownPayment.AutoSize = True
        Me.lblDownPayment.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDownPayment.Location = New System.Drawing.Point(80, 111)
        Me.lblDownPayment.Name = "lblDownPayment"
        Me.lblDownPayment.Size = New System.Drawing.Size(154, 29)
        Me.lblDownPayment.TabIndex = 0
        Me.lblDownPayment.Text = "Down Payment"
        '
        'lblInterestRate
        '
        Me.lblInterestRate.AutoSize = True
        Me.lblInterestRate.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInterestRate.Location = New System.Drawing.Point(80, 161)
        Me.lblInterestRate.Name = "lblInterestRate"
        Me.lblInterestRate.Size = New System.Drawing.Size(133, 29)
        Me.lblInterestRate.TabIndex = 1
        Me.lblInterestRate.Text = "Interest Rate"
        '
        'lblNumberOfYears
        '
        Me.lblNumberOfYears.AutoSize = True
        Me.lblNumberOfYears.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumberOfYears.Location = New System.Drawing.Point(80, 211)
        Me.lblNumberOfYears.Name = "lblNumberOfYears"
        Me.lblNumberOfYears.Size = New System.Drawing.Size(171, 29)
        Me.lblNumberOfYears.TabIndex = 2
        Me.lblNumberOfYears.Text = "Number of Years"
        '
        'txtDownPayment
        '
        Me.txtDownPayment.Location = New System.Drawing.Point(260, 116)
        Me.txtDownPayment.Name = "txtDownPayment"
        Me.txtDownPayment.Size = New System.Drawing.Size(100, 22)
        Me.txtDownPayment.TabIndex = 3
        '
        'txtInterestRate
        '
        Me.txtInterestRate.Location = New System.Drawing.Point(260, 166)
        Me.txtInterestRate.Name = "txtInterestRate"
        Me.txtInterestRate.Size = New System.Drawing.Size(100, 22)
        Me.txtInterestRate.TabIndex = 4
        '
        'txtNumberOfYears
        '
        Me.txtNumberOfYears.Location = New System.Drawing.Point(260, 216)
        Me.txtNumberOfYears.Name = "txtNumberOfYears"
        Me.txtNumberOfYears.Size = New System.Drawing.Size(100, 22)
        Me.txtNumberOfYears.TabIndex = 5
        '
        'lblPayment
        '
        Me.lblPayment.AutoSize = True
        Me.lblPayment.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPayment.Location = New System.Drawing.Point(13, 13)
        Me.lblPayment.Name = "lblPayment"
        Me.lblPayment.Size = New System.Drawing.Size(268, 35)
        Me.lblPayment.TabIndex = 6
        Me.lblPayment.Text = "Home Down Payment"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(260, 283)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(120, 84)
        Me.ListBox1.TabIndex = 7
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 267)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(222, 224)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'homeDownPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(570, 525)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.lblPayment)
        Me.Controls.Add(Me.txtNumberOfYears)
        Me.Controls.Add(Me.txtInterestRate)
        Me.Controls.Add(Me.txtDownPayment)
        Me.Controls.Add(Me.lblNumberOfYears)
        Me.Controls.Add(Me.lblInterestRate)
        Me.Controls.Add(Me.lblDownPayment)
        Me.Name = "homeDownPayment"
        Me.Text = "Home Down Payment"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDownPayment As Label
    Friend WithEvents lblInterestRate As Label
    Friend WithEvents lblNumberOfYears As Label
    Friend WithEvents txtDownPayment As TextBox
    Friend WithEvents txtInterestRate As TextBox
    Friend WithEvents txtNumberOfYears As TextBox
    Friend WithEvents lblPayment As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
