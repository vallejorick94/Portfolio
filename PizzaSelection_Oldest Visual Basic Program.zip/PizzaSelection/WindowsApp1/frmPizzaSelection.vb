﻿'PROGRAM NAME: PIZZA SELECTION
'PROGRAMMER: RICKY VALLEJO
'DATE: 2/9/2018
'PURPOSE: PROGRAM DISPLAYS TOPPING FOR PIZZA

Public Class PizzaSelection
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Pepperoni.Click
        picPepperoni.Visible = True
        picSausage.Visible = False
        btnSelect.Enabled = False
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Sausage.Click

    End Sub
    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        picPepperoni.Visible = False
        picSausage.Visible = False
        btnSelect.Enabled = False
        lblInstructions.Visible = False
        lblConfirmation.Visible = True
    End Sub

    Private Sub picPepperoni_Click(sender As Object, e As EventArgs) Handles picPepperoni.Click

    End Sub
End Class
