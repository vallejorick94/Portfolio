﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PizzaSelection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PizzaSelection))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.picPepperoni = New System.Windows.Forms.PictureBox()
        Me.picSausage = New System.Windows.Forms.PictureBox()
        Me.Pepperoni = New System.Windows.Forms.Button()
        Me.Sausage = New System.Windows.Forms.Button()
        Me.btnSelect = New System.Windows.Forms.Button()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.lblConfirmation = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.picPepperoni, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSausage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(346, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(157, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pizza Selection"
        '
        'picPepperoni
        '
        Me.picPepperoni.Enabled = False
        Me.picPepperoni.Image = CType(resources.GetObject("picPepperoni.Image"), System.Drawing.Image)
        Me.picPepperoni.Location = New System.Drawing.Point(213, 108)
        Me.picPepperoni.Name = "picPepperoni"
        Me.picPepperoni.Size = New System.Drawing.Size(125, 109)
        Me.picPepperoni.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPepperoni.TabIndex = 1
        Me.picPepperoni.TabStop = False
        Me.picPepperoni.Visible = False
        '
        'picSausage
        '
        Me.picSausage.Enabled = False
        Me.picSausage.Image = CType(resources.GetObject("picSausage.Image"), System.Drawing.Image)
        Me.picSausage.Location = New System.Drawing.Point(511, 108)
        Me.picSausage.Name = "picSausage"
        Me.picSausage.Size = New System.Drawing.Size(125, 109)
        Me.picSausage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSausage.TabIndex = 2
        Me.picSausage.TabStop = False
        Me.picSausage.Visible = False
        '
        'Pepperoni
        '
        Me.Pepperoni.Location = New System.Drawing.Point(219, 244)
        Me.Pepperoni.Name = "Pepperoni"
        Me.Pepperoni.Size = New System.Drawing.Size(108, 23)
        Me.Pepperoni.TabIndex = 3
        Me.Pepperoni.Text = "Pepperoni"
        Me.Pepperoni.UseVisualStyleBackColor = True
        '
        'Sausage
        '
        Me.Sausage.Location = New System.Drawing.Point(521, 244)
        Me.Sausage.Name = "Sausage"
        Me.Sausage.Size = New System.Drawing.Size(108, 23)
        Me.Sausage.TabIndex = 4
        Me.Sausage.Text = "Sausage"
        Me.Sausage.UseVisualStyleBackColor = True
        '
        'btnSelect
        '
        Me.btnSelect.Enabled = False
        Me.btnSelect.Location = New System.Drawing.Point(370, 244)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.Size = New System.Drawing.Size(108, 23)
        Me.btnSelect.TabIndex = 5
        Me.btnSelect.Text = "Select Pizza"
        Me.btnSelect.UseVisualStyleBackColor = True
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(273, 309)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(302, 17)
        Me.lblInstructions.TabIndex = 6
        Me.lblInstructions.Text = "Choose a Topping and Select the Pizza Button"
        '
        'lblConfirmation
        '
        Me.lblConfirmation.AutoSize = True
        Me.lblConfirmation.Location = New System.Drawing.Point(336, 364)
        Me.lblConfirmation.Name = "lblConfirmation"
        Me.lblConfirmation.Size = New System.Drawing.Size(177, 17)
        Me.lblConfirmation.TabIndex = 7
        Me.lblConfirmation.Text = "Enjoy Your Pizza Selection"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(370, 412)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(108, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit Selection" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'PizzaSelection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(849, 511)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblConfirmation)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.btnSelect)
        Me.Controls.Add(Me.Sausage)
        Me.Controls.Add(Me.Pepperoni)
        Me.Controls.Add(Me.picSausage)
        Me.Controls.Add(Me.picPepperoni)
        Me.Controls.Add(Me.Label1)
        Me.Name = "PizzaSelection"
        Me.Text = "Pizza Selection"
        CType(Me.picPepperoni, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSausage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents picPepperoni As PictureBox
    Friend WithEvents picSausage As PictureBox
    Friend WithEvents Pepperoni As Button
    Friend WithEvents Sausage As Button
    Friend WithEvents btnSelect As Button
    Friend WithEvents lblInstructions As Label
    Friend WithEvents lblConfirmation As Label
    Friend WithEvents btnExit As Button
End Class
