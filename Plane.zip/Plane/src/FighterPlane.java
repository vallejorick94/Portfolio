
public class FighterPlane extends PlaneDecorator{
	public FighterPlane(PlaneInterface plane){
		super(plane);
	}
	@Override
	public void make(){
		super.make();
		System.out.println("Adding fighter plane features");
	}
}
