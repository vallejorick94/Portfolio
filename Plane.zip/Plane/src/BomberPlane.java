
public class BomberPlane extends PlaneDecorator{
	public BomberPlane(PlaneInterface plane){
		super(plane);
	}
	@Override
	public void make(){
		super.make();
		System.out.println("Adding bomber plane features");
	}
}
