
public interface PlaneInterface {
	public void make();
	public String getName();
}
