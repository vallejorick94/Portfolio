public class PlaneDecorator implements PlaneInterface{
	private PlaneInterface plane; //wrappee	
	public PlaneDecorator(PlaneInterface plane){
		this.plane = plane;
	}
	@Override
	public void make() {
		plane.make();
	}
	@Override
	public String getName() {
		return plane.getName();
	}
}