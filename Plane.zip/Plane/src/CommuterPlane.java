
public class CommuterPlane extends PlaneDecorator{
	public CommuterPlane(PlaneInterface plane){
		super(plane);
	}
	@Override
	public void make(){
		super.make();
		System.out.println("Adding commuter plane features");
	}
}
