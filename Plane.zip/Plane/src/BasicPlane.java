
public class BasicPlane implements PlaneInterface{
	private String name;
	public BasicPlane(String name){
		this.name = name;
	}
	public String getName(){
		return name;
	}
	@Override
	public void make() {
		System.out.println("Basic Plane make");
	}
}
