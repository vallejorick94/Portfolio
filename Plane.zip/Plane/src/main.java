
public class main {
	public static void main(String[] args){
		PlaneInterface plane = new BasicPlane("Jet");

		plane = new BomberPlane(plane);
		plane.getName();
		
		plane = new FighterPlane(plane);
		plane.getName();
		
		plane = new CommuterPlane(plane);
		plane.make();
		plane.getName();
	}
}
