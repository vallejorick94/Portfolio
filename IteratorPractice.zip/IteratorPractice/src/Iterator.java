//Create a program that has a container of players 
//on a team and an iterator to iterate through the 
//collection of players in the container.

public interface Iterator {
	public boolean hasNext();
	public Object next();
	
}
