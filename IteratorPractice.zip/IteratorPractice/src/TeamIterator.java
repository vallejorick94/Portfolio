
public class TeamIterator implements Iterator{
	Team[] playerList;
	
	int pos = 0;
	
	public TeamIterator(Team[] playerList){
		this.playerList = playerList;
	}
	public Object next(){
		Team playerName = playerList[pos];
		pos += 1;
		return playerName;
	}
	public boolean hasNext(){
		if(pos >= playerList.length || playerList[pos]  == null)
			return false;
		else
			return true;
	}
}
