
public class PlayerName {
	TeamContainer team;
	public PlayerName(TeamContainer team){
		this.team = team;
	}
	public void printTeam(){
		Iterator iterator = team.getIterator();
		System.out.println("Team");
		while(iterator.hasNext()){
			Team t = (Team)iterator.next();
			System.out.println(t.getPlayerName());
		}
				
	}
}
