
public class Main {
	public static void main(String args[]){
		TeamContainer tc = new TeamContainer();
		PlayerName te = new PlayerName(tc);
		te.printTeam();
	}
}
