
public class Team {
	String playerName;
	public Team(String playerName){
		this.playerName = playerName;
	}
	public String getPlayerName(){
		return playerName;
	}
}
