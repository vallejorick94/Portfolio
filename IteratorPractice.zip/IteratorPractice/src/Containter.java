
public interface Containter {
	public Iterator getIterator();
}
