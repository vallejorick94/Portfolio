
class TeamContainer implements Containter{
	static final int MAX_PLAYERS = 10;
	int numberOfPlayers = 0;
	Team[] playerList;
	
	public TeamContainer(){
		playerList = new Team[MAX_PLAYERS];
		addItem("Bob Kelso");
		addItem("John Dorian");
		addItem("Dr. Cox");
	}
	
	public void addItem(String str){
		Team playerName = new Team(str);
		if(numberOfPlayers >= MAX_PLAYERS)
			System.out.println("Full");
		else{
			playerList[numberOfPlayers] = playerName;
			numberOfPlayers = numberOfPlayers + 1;
		}
	}
	public Iterator getIterator(){
		return new TeamIterator(playerList);
	}
}
