
public class SingletonPractice {
	private static SingletonPractice mySing;
	
	//Create private constructor
	private SingletonPractice(){	
	}
	
	//create a static method to get the instance
	public static SingletonPractice makeInstance(){
		if(mySing == null){
			mySing = new SingletonPractice();
		}
		return mySing;
	}
	
	public void makeOutput(){
		//executes something
		System.out.println("I am practicing Singletons!");
	}
}
