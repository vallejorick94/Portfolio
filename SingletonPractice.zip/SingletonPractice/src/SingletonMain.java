
public class SingletonMain {
	public static void main(String[] args){
		SingletonPractice sing = SingletonPractice.makeInstance();
		sing.makeOutput();
	}
}
