import java.util.ArrayList;

public class Dealer extends Player {

	private Deck d;
	
	public Dealer(String name) {
		super(name);
		// TODO Auto-generated constructor stub
		d = new Deck();
	}
	
	public Dealer(String name, Hand h){
		super(name, h);
		d = new Deck();
	}
	
	public Dealer(String name, Hand h, Deck d){
		super(name, h);
		this.d = d;
	}
	
	public Dealer(String name, Deck d){
		super(name);
		this.d = d;
	}
	
	public Deck getDeck(){
		return d;
	}
	
	public Card dealCard(){
		int cardsPerPlayer = 5;
	 
		for(int i = 0; i < cardsPerPlayer; i++){
			System.out.print(d.deckInformation());
			if(i % cardsPerPlayer == cardsPerPlayer - 1)
				System.out.println();
		}
		return d.dealCard();
	}
	
	public ArrayList<Card> dealCards(int num){
		ArrayList<Card> cards = new ArrayList<Card>();
		
		for(int i = 0; i < num; i++){
			cards.add(d.dealCard());
		}
		
		return cards;
	}
	

}
