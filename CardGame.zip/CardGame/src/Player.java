

public class Player {
	private String name;
	private Hand h;
	
	public Player(String name){
		this.name = name;
	}
	
	public Player(String name, Hand h){
		this.name = name;
		this.h = h;
	}
	
	//accessors
	public String getName(){
		return name;
	}
	
	public Hand getHand(){
		return h;
	}
	
	//mutators
	public void setHand(Hand h){
		this.h = h;
	}
	
	public Card getCard(String suit, String rank){
		return h.removeCard(suit, rank);
	}
	
}
