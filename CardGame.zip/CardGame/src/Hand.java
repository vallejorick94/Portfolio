import java.util.ArrayList;

public class Hand {
	private ArrayList<Card> hand;
	
	public Hand(){
		hand = new ArrayList<Card>();
	}
	
	public Hand(ArrayList<Card> hand){
		this.hand = hand;
	}
	
	//accessors
	public ArrayList<Card> getHand(){
		return hand;
	}
	
	//mutator sethand
	public void setHand(ArrayList<Card> hand){
		this.hand = hand;
	}
	
	public void addCard(Card c){
		hand.add(c);
	}
	
	public boolean hasCard(Card c){
		return hand.contains(c);
	}
	
	public boolean hasCard(String suit, String rank){
		for(int i = 0; i < hand.size(); i++){
			if(hand.get(i).getRank().equals(rank) && hand.get(i).getSuit().equals(suit)){
				return true;
			}
		}
		
		return false;
	}
	
	public Card removeCard(String suit, String rank){
		for(int i = 0; i < hand.size(); i++){
			if(hand.get(i).getRank().equals(rank) && hand.get(i).getSuit().equals(suit)){
				return hand.remove(i);
			}
		}
		
		return null;
	}
	
}
