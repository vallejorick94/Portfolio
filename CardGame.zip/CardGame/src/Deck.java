import java.util.ArrayList;

public class Deck {
	private ArrayList<Card> deck;
	
	private String[] suits = {"Diamonds", "Hearts", "Spades", "Clubs"};
	private String[] ranks = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};

	public Deck(){
		deck = new ArrayList<Card>();
		
		for(int i = 0; i < suits.length; i++){
			for(int j = 0; j < ranks.length; j++){
				deck.add(new Card(suits[i], ranks[j]));
			}
		}
	}
	
	public Deck(String[] s, String[] r){
		deck = new ArrayList<Card>();
		
		for(int i = 0; i < s.length; i++){
			for(int j = 0; j < r.length; j++){
				deck.add(new Card(s[i], r[j]));
			}
		}
	}
	
	public String deckInformation(){
		String output = "";
		for(int i = 0; i < deck.size(); i++){
			output += deck.get(i).toString() + "\n";
		}
	
		return output;
	}
	
	
	public void shuffleDeck(){
		for(int i = 0; i < deck.size(); i++){
			int val = (int) (deck.size() * Math.random());
			
			Card temp = deck.get(val);
			deck.set(val, deck.get(i));
			deck.set(i, temp);
		}
	}
	
	public Card dealCard(){
		return deck.remove(0);
	}
	
	public void addCard(Card c){
		deck.add(c);
	}
}
