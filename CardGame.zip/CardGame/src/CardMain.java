
public class CardMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deck d = new Deck();
		System.out.println(d.deckInformation());
		d.shuffleDeck();
		System.out.println(d.deckInformation());
		d.dealCard();
		System.out.println(d.deckInformation());
	}

}