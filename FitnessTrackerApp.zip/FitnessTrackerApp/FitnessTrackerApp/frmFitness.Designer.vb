﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmFitness
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFitness))
        Me.lblFitness = New System.Windows.Forms.Label()
        Me.lblEnter = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblBirthDate = New System.Windows.Forms.Label()
        Me.lblCurrentDate = New System.Windows.Forms.Label()
        Me.lblMonth = New System.Windows.Forms.Label()
        Me.lblDay = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblCurrentMonth = New System.Windows.Forms.Label()
        Me.lblCurrentDay = New System.Windows.Forms.Label()
        Me.lblCurrentYear = New System.Windows.Forms.Label()
        Me.txtBirthMonth = New System.Windows.Forms.TextBox()
        Me.txtBirthDay = New System.Windows.Forms.TextBox()
        Me.txtBirthYear = New System.Windows.Forms.TextBox()
        Me.txtCurrentMonth = New System.Windows.Forms.TextBox()
        Me.txtCurrentDay = New System.Windows.Forms.TextBox()
        Me.txtCurrentYear = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtOutputName = New System.Windows.Forms.TextBox()
        Me.lblOutputName = New System.Windows.Forms.Label()
        Me.lblTotalHours = New System.Windows.Forms.Label()
        Me.txtTotalHours = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblFitness
        '
        Me.lblFitness.AutoSize = True
        Me.lblFitness.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblFitness.Font = New System.Drawing.Font("Calibri", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFitness.Location = New System.Drawing.Point(23, 24)
        Me.lblFitness.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblFitness.Name = "lblFitness"
        Me.lblFitness.Size = New System.Drawing.Size(271, 39)
        Me.lblFitness.TabIndex = 0
        Me.lblFitness.Text = "Fitness Tracker App"
        '
        'lblEnter
        '
        Me.lblEnter.AutoSize = True
        Me.lblEnter.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblEnter.Font = New System.Drawing.Font("Calibri", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEnter.Location = New System.Drawing.Point(26, 90)
        Me.lblEnter.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblEnter.Name = "lblEnter"
        Me.lblEnter.Size = New System.Drawing.Size(61, 27)
        Me.lblEnter.TabIndex = 1
        Me.lblEnter.Text = "Enter"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblName.Font = New System.Drawing.Font("Calibri", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(113, 90)
        Me.lblName.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(121, 27)
        Me.lblName.TabIndex = 2
        Me.lblName.Text = "First Name: "
        '
        'lblBirthDate
        '
        Me.lblBirthDate.AutoSize = True
        Me.lblBirthDate.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblBirthDate.Font = New System.Drawing.Font("Calibri", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBirthDate.Location = New System.Drawing.Point(397, 90)
        Me.lblBirthDate.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblBirthDate.Name = "lblBirthDate"
        Me.lblBirthDate.Size = New System.Drawing.Size(110, 27)
        Me.lblBirthDate.TabIndex = 3
        Me.lblBirthDate.Text = "Birth Date:"
        '
        'lblCurrentDate
        '
        Me.lblCurrentDate.AutoSize = True
        Me.lblCurrentDate.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblCurrentDate.Font = New System.Drawing.Font("Calibri", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentDate.Location = New System.Drawing.Point(397, 162)
        Me.lblCurrentDate.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblCurrentDate.Name = "lblCurrentDate"
        Me.lblCurrentDate.Size = New System.Drawing.Size(136, 27)
        Me.lblCurrentDate.TabIndex = 4
        Me.lblCurrentDate.Text = "Current Date:"
        '
        'lblMonth
        '
        Me.lblMonth.AutoSize = True
        Me.lblMonth.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblMonth.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMonth.Location = New System.Drawing.Point(567, 97)
        Me.lblMonth.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblMonth.Name = "lblMonth"
        Me.lblMonth.Size = New System.Drawing.Size(51, 19)
        Me.lblMonth.TabIndex = 5
        Me.lblMonth.Text = "Month"
        '
        'lblDay
        '
        Me.lblDay.AutoSize = True
        Me.lblDay.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblDay.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDay.Location = New System.Drawing.Point(644, 97)
        Me.lblDay.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblDay.Name = "lblDay"
        Me.lblDay.Size = New System.Drawing.Size(34, 19)
        Me.lblDay.TabIndex = 6
        Me.lblDay.Text = "Day"
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblYear.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYear.Location = New System.Drawing.Point(695, 97)
        Me.lblYear.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(37, 19)
        Me.lblYear.TabIndex = 7
        Me.lblYear.Text = "Year"
        '
        'lblCurrentMonth
        '
        Me.lblCurrentMonth.AutoSize = True
        Me.lblCurrentMonth.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblCurrentMonth.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentMonth.Location = New System.Drawing.Point(567, 169)
        Me.lblCurrentMonth.Name = "lblCurrentMonth"
        Me.lblCurrentMonth.Size = New System.Drawing.Size(51, 19)
        Me.lblCurrentMonth.TabIndex = 8
        Me.lblCurrentMonth.Text = "Month"
        '
        'lblCurrentDay
        '
        Me.lblCurrentDay.AutoSize = True
        Me.lblCurrentDay.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblCurrentDay.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentDay.Location = New System.Drawing.Point(644, 169)
        Me.lblCurrentDay.Name = "lblCurrentDay"
        Me.lblCurrentDay.Size = New System.Drawing.Size(34, 19)
        Me.lblCurrentDay.TabIndex = 9
        Me.lblCurrentDay.Text = "Day"
        '
        'lblCurrentYear
        '
        Me.lblCurrentYear.AutoSize = True
        Me.lblCurrentYear.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblCurrentYear.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentYear.Location = New System.Drawing.Point(695, 169)
        Me.lblCurrentYear.Name = "lblCurrentYear"
        Me.lblCurrentYear.Size = New System.Drawing.Size(37, 19)
        Me.lblCurrentYear.TabIndex = 10
        Me.lblCurrentYear.Text = "Year"
        '
        'txtBirthMonth
        '
        Me.txtBirthMonth.Location = New System.Drawing.Point(571, 125)
        Me.txtBirthMonth.Name = "txtBirthMonth"
        Me.txtBirthMonth.Size = New System.Drawing.Size(63, 28)
        Me.txtBirthMonth.TabIndex = 11
        '
        'txtBirthDay
        '
        Me.txtBirthDay.Location = New System.Drawing.Point(648, 125)
        Me.txtBirthDay.Name = "txtBirthDay"
        Me.txtBirthDay.Size = New System.Drawing.Size(37, 28)
        Me.txtBirthDay.TabIndex = 12
        '
        'txtBirthYear
        '
        Me.txtBirthYear.Location = New System.Drawing.Point(692, 125)
        Me.txtBirthYear.Name = "txtBirthYear"
        Me.txtBirthYear.Size = New System.Drawing.Size(49, 28)
        Me.txtBirthYear.TabIndex = 13
        '
        'txtCurrentMonth
        '
        Me.txtCurrentMonth.Location = New System.Drawing.Point(571, 196)
        Me.txtCurrentMonth.Name = "txtCurrentMonth"
        Me.txtCurrentMonth.Size = New System.Drawing.Size(63, 28)
        Me.txtCurrentMonth.TabIndex = 14
        '
        'txtCurrentDay
        '
        Me.txtCurrentDay.Location = New System.Drawing.Point(648, 196)
        Me.txtCurrentDay.Name = "txtCurrentDay"
        Me.txtCurrentDay.Size = New System.Drawing.Size(37, 28)
        Me.txtCurrentDay.TabIndex = 15
        '
        'txtCurrentYear
        '
        Me.txtCurrentYear.Location = New System.Drawing.Point(692, 196)
        Me.txtCurrentYear.Name = "txtCurrentYear"
        Me.txtCurrentYear.Size = New System.Drawing.Size(49, 28)
        Me.txtCurrentYear.TabIndex = 16
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(262, 91)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 28)
        Me.txtName.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 417)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 24)
        Me.Label1.TabIndex = 18
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnCalculate.Location = New System.Drawing.Point(403, 259)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(135, 48)
        Me.btnCalculate.TabIndex = 19
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnClear.Location = New System.Drawing.Point(639, 259)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(102, 48)
        Me.btnClear.TabIndex = 20
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'txtOutputName
        '
        Me.txtOutputName.Location = New System.Drawing.Point(641, 346)
        Me.txtOutputName.Name = "txtOutputName"
        Me.txtOutputName.Size = New System.Drawing.Size(100, 28)
        Me.txtOutputName.TabIndex = 21
        '
        'lblOutputName
        '
        Me.lblOutputName.AutoSize = True
        Me.lblOutputName.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblOutputName.Location = New System.Drawing.Point(431, 351)
        Me.lblOutputName.Name = "lblOutputName"
        Me.lblOutputName.Size = New System.Drawing.Size(61, 24)
        Me.lblOutputName.TabIndex = 22
        Me.lblOutputName.Text = "Name"
        '
        'lblTotalHours
        '
        Me.lblTotalHours.AutoSize = True
        Me.lblTotalHours.BackColor = System.Drawing.Color.RoyalBlue
        Me.lblTotalHours.Location = New System.Drawing.Point(343, 400)
        Me.lblTotalHours.Name = "lblTotalHours"
        Me.lblTotalHours.Size = New System.Drawing.Size(196, 24)
        Me.lblTotalHours.TabIndex = 23
        Me.lblTotalHours.Text = "Total Hours in Lifetime"
        '
        'txtTotalHours
        '
        Me.txtTotalHours.Location = New System.Drawing.Point(641, 395)
        Me.txtTotalHours.Name = "txtTotalHours"
        Me.txtTotalHours.Size = New System.Drawing.Size(100, 28)
        Me.txtTotalHours.TabIndex = 24
        '
        'frmFitness
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 22.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(782, 503)
        Me.Controls.Add(Me.txtTotalHours)
        Me.Controls.Add(Me.lblTotalHours)
        Me.Controls.Add(Me.lblOutputName)
        Me.Controls.Add(Me.txtOutputName)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtCurrentYear)
        Me.Controls.Add(Me.txtCurrentDay)
        Me.Controls.Add(Me.txtCurrentMonth)
        Me.Controls.Add(Me.txtBirthYear)
        Me.Controls.Add(Me.txtBirthDay)
        Me.Controls.Add(Me.txtBirthMonth)
        Me.Controls.Add(Me.lblCurrentYear)
        Me.Controls.Add(Me.lblCurrentDay)
        Me.Controls.Add(Me.lblCurrentMonth)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblDay)
        Me.Controls.Add(Me.lblMonth)
        Me.Controls.Add(Me.lblCurrentDate)
        Me.Controls.Add(Me.lblBirthDate)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.lblEnter)
        Me.Controls.Add(Me.lblFitness)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.Name = "frmFitness"
        Me.Text = "Fitness Tracker App"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblFitness As Label
    Friend WithEvents lblEnter As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblBirthDate As Label
    Friend WithEvents lblCurrentDate As Label
    Friend WithEvents lblMonth As Label
    Friend WithEvents lblDay As Label
    Friend WithEvents lblYear As Label
    Friend WithEvents lblCurrentMonth As Label
    Friend WithEvents lblCurrentDay As Label
    Friend WithEvents lblCurrentYear As Label
    Friend WithEvents txtBirthMonth As TextBox
    Friend WithEvents txtBirthDay As TextBox
    Friend WithEvents txtBirthYear As TextBox
    Friend WithEvents txtCurrentMonth As TextBox
    Friend WithEvents txtCurrentDay As TextBox
    Friend WithEvents txtCurrentYear As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents txtOutputName As TextBox
    Friend WithEvents lblOutputName As Label
    Friend WithEvents lblTotalHours As Label
    Friend WithEvents txtTotalHours As TextBox
End Class
