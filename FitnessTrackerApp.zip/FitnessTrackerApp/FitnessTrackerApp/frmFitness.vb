﻿'Program: Fitness Track App
'Author: Ricky Vallejo
'Date: 3/3/2018
'Purpose: This application calculates the number of hours one has done in their 
'lifetime assuming they have worked out For 2.5 hours every week


Option Strict On
Public Class frmFitness
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblFitness.Click

    End Sub

    Private Sub frmFitness_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblMonth_Click(sender As Object, e As EventArgs) Handles lblMonth.Click

    End Sub

    Private Sub lblDay_Click(sender As Object, e As EventArgs) Handles lblDay.Click

    End Sub

    Private Sub lblYear_Click(sender As Object, e As EventArgs) Handles lblYear.Click

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles txtCurrentMonth.TextChanged

    End Sub

    Private Sub lblCurrentDate_Click(sender As Object, e As EventArgs) Handles lblCurrentDate.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles lblTotalHours.Click

    End Sub

    Private Sub txtOutputName_TextChanged(sender As Object, e As EventArgs) Handles txtOutputName.TextChanged

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'calculates the total number of hours when it is clicked
        Dim decTotalHours As Decimal
        Dim strFirstName As String
        Dim decCurrentYear As Integer
        Dim decBirthYear As Integer

        'Input for name 
        strFirstName = txtName.Text
        txtOutputName.Text = strFirstName

        'taking the input and converting to decimal values
        decBirthYear = CInt(txtBirthYear.Text)
        decCurrentYear = CInt(txtCurrentYear.Text)
        decTotalHours = CDec((decCurrentYear - decBirthYear) * 52 * 2.5)

        'total number of hours text 
        txtTotalHours.Text = CType(decTotalHours, String)
    End Sub

    Private Sub txtBirthYear_TextChanged(sender As Object, e As EventArgs) Handles txtBirthYear.TextChanged

    End Sub

    Private Sub txtCurrentYear_TextChanged(sender As Object, e As EventArgs) Handles txtCurrentYear.TextChanged

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'this button clears all the text so that the program may be run again
        txtName.Clear()
        txtBirthDay.Clear()
        txtBirthMonth.Clear()
        txtBirthYear.Clear()

        txtCurrentDay.Clear()
        txtCurrentMonth.Clear()
        txtCurrentYear.Clear()

        txtOutputName.Clear()
        txtTotalHours.Clear()
    End Sub
End Class
