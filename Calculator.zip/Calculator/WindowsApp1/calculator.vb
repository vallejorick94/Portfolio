﻿'Program Name- Calculator
'Author- Ricky Vallejo
'Date- March 14, 2018
'Purpose- the program is a calculator that calculates by having a number clicked followed
'by an operation, then another number

'Option Strict On
Public Class calculator

    Dim firstNumber As Integer = 0
    Dim firstEntered As Boolean = False
    Dim operation As Integer = 0


    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn9.Click, btn8.Click, btn7.Click, btn6.Click, btn5.Click, btn4.Click, btn3.Click, btn2.Click, btn1.Click, btn0.Click
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub


    Private Sub btn2_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btn5_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btn6_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btn7_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btn8_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btn9_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblDisplay.Text = ""
    End Sub

    Private Sub btn0_Click(sender As Object, e As EventArgs)
        If lblDisplay.Text.Length < 10 Then
            lblDisplay.Text = lblDisplay.Text + sender.Text
        End If
    End Sub

    Private Sub btnEquals_Click(sender As Object, e As EventArgs) Handles btnEquals.Click
        If firstEntered Then
            If lblDisplay.Text <> vbNullString Then
                Dim secondNumber As Double = lblDisplay.Text
                Dim answer As Double
                Select Case operation
                    Case 1
                        answer = firstNumber + secondNumber
                    Case 2
                        answer = firstNumber - secondNumber
                    Case 3
                        answer = firstNumber * secondNumber
                    Case 4
                        answer = firstNumber / secondNumber
                        If secondNumber = 0 Then
                            MessageBox.Show("You cannot divide by 0!")
                            lblDisplay.Text = ""
                            answer = 0
                        End If
                End Select
                If operation >= 1 And operation <= 4 Then
                    lblDisplay.Text = answer
                    firstNumber = answer
                End If
            End If
        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If lblDisplay.Text <> vbNullString Then
            firstNumber = lblDisplay.Text
            firstEntered = True
            operation = 1
            lblDisplay.Text = ""
        End If

    End Sub

    Private Sub btnMulti_Click(sender As Object, e As EventArgs) Handles btnMulti.Click
        If lblDisplay.Text <> vbNullString Then
            firstNumber = lblDisplay.Text
            firstEntered = True
            operation = 3
            lblDisplay.Text = ""
        End If
    End Sub

    Private Sub btnDiv_Click(sender As Object, e As EventArgs) Handles btnDiv.Click
        If lblDisplay.Text <> vbNullString Then
            firstNumber = lblDisplay.Text
            firstEntered = True
            operation = 4
            lblDisplay.Text = ""
        End If
    End Sub

    Private Sub btnSub_Click(sender As Object, e As EventArgs) Handles btnSub.Click
        If lblDisplay.Text <> vbNullString Then
            firstNumber = lblDisplay.Text
            firstEntered = True
            operation = 2
            lblDisplay.Text = ""
        End If
    End Sub

    Private Sub calculator_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn0_Click_1(sender As Object, e As EventArgs)

    End Sub
End Class